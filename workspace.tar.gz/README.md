1. install node.js 
2. RUN: git clone https://github.com/abbasEbadian/hi-exchange.git
3. RUN: npm i   or   npm install
4. RUN: npm start  or serve -s build (if build folder exists)
5. RUN: node proxy.js ( For CoinMarketCap API requests). Should be executed in a standalone terminal.
